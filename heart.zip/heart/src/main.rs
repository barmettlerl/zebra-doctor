use std::env;
use std::collections::HashMap;
use std::time::Instant;

use dashmap::DashMap;
use tenaciouszebra::database::{TableTransaction, Database, Table};

use crate::helpers::with_percentage_true;

mod commands;
mod helpers;


fn get_test_method(args: &Vec<String>) -> String {
    for i in 0..args.len() {
        if args[i] == format!("--{}", "method") {
            return args[i+1].clone();
        }
    }
    String::from("none")
}


fn get_backup_type(args: &Vec<String>) -> String {
    for i in 0..args.len() {
        if args[i] == format!("--{}", "backup-type") {
            return args[i+1].clone();
        }
    }
    String::from("none")
}

fn run_single_rocksdb_test(write_percentage: f64) {
    let mut db = Database::<String, i32>::new("test");
    db.empty_table("test");

    let start: Instant = Instant::now();
    for i in 0..100 {
        let test_table = db.get_table("test").unwrap();
        let mut modify = TableTransaction::new();
        for j in 0..1000 {
            if with_percentage_true(write_percentage) {
                modify.set(format!("{}{}", i, j), j).unwrap();
            } else {
                modify.get(&format!("{}{}", i, j)).unwrap();
            }
        }
        test_table.execute(modify);
    }

    let duration = start.elapsed();

    println!("Time elapsed in run_single_rocksdb_test() is: {:?} with write percentage: {}", duration, write_percentage);
}

fn run_hash_table_operations(write_percentage: f64) {
    let mut db = HashMap::<String, i32>::new();
    db.insert(String::from("1"), 1);
    let start: Instant = Instant::now();
    for i in 0..100 {
        for j in 0..1000 {
            if with_percentage_true(write_percentage) {
                db.insert(format!("{}{}", i, j), j);
            } else {
                db.get(&"1".to_string());
            }
        }
    }
    let duration = start.elapsed();

    println!("Time elapsed in run_hash_table_operations() is: {:?} with write percentage: {}", duration, write_percentage);
}


fn run_dashmap_table_operations(write_percentage: f64) {
    let db = DashMap::<String, i32>::new();
    db.insert(String::from("1"), 1);
    let start: Instant = Instant::now();
    for i in 0..100 {
        for j in 0..1000 {
            if with_percentage_true(write_percentage) {
                db.insert(format!("{}{}", i, j), j);
            } else {
                db.get(&"1".to_string());
            }
        }
    }
    let duration = start.elapsed();

    println!("Time elapsed in run_dashmap_table_operations() is: {:?} with write percentage: {}", duration, write_percentage);
}

fn main() {
    let args: Vec<String> = env::args().collect();

    let test_method = get_test_method(&args);
    let backup_type = get_backup_type(&args);


    run_single_rocksdb_test(50.0);
    run_single_rocksdb_test(100.0);
    run_hash_table_operations(50.0);
    run_hash_table_operations(100.0);
    run_dashmap_table_operations(50.0);
    run_dashmap_table_operations(100.0);
    
}
